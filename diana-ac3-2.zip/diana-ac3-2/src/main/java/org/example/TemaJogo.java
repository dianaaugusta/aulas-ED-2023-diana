package org.example;

public class TemaJogo {
    private int id;
    private Double valor = 0.0;
    private int qtdVendidasOuPlayersAtivos;
    private String nomeJogo;
    private Double notaJogoMetacritic = 0.0;
    private boolean ehOnline = false;

    public TemaJogo(int id, Double valor, int qtdVendidasOuPlayersAtivos, String nomeJogo, Double notaJogoMetacritic, boolean ehOnline) {
        this.id = id;
        this.valor = valor;
        this.qtdVendidasOuPlayersAtivos = qtdVendidasOuPlayersAtivos;
        this.nomeJogo = nomeJogo;
        this.notaJogoMetacritic = notaJogoMetacritic;
        this.ehOnline = ehOnline;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public int getQtdVendidasOuPlayersAtivos() {
        return qtdVendidasOuPlayersAtivos;
    }

    public void setQtdVendidasOuPlayersAtivos(int qtdVendidasOuPlayersAtivos) {
        this.qtdVendidasOuPlayersAtivos = qtdVendidasOuPlayersAtivos;
    }

    public String getNomeJogo() {
        return nomeJogo;
    }

    public void setNomeJogo(String nomeJogo) {
        this.nomeJogo = nomeJogo;
    }

    public Double getNotaJogoMetacritic() {
        return notaJogoMetacritic;
    }

    public void setNotaJogoMetacritic(Double notaJogoMetacritic) {
        this.notaJogoMetacritic = notaJogoMetacritic;
    }

    public boolean isEhOnline() {
        return ehOnline;
    }

    public void setEhOnline(boolean ehOnline) {
        this.ehOnline = ehOnline;
    }

    @Override
    public String toString() {
        return "TemaJogo{" +
                "id=" + id +
                ", valor=" + valor +
                ", qtdVendidasOuPlayersAtivos=" + qtdVendidasOuPlayersAtivos +
                ", nomeJogo='" + nomeJogo + '\'' +
                ", notaJogoMetacritic=" + notaJogoMetacritic +
                ", ehOnline=" + ehOnline +
                '}';
    }
}
