package org.example;

import org.example.utils.FilaObj;
import org.example.utils.ListaObj;
import org.example.utils.PilhaObj;

public class RepositorioEmpresaJogo {
    private ListaObj<TemaJogo> lista;
    private PilhaObj<Operacao> pilha;
    private FilaObj<Integer> fila;
    private int contadorOperacoesEmpilhadas;

    public RepositorioEmpresaJogo(int capacidadeLista, int capacidadePilha, int capacidadeFila) {
        lista = new ListaObj<>(capacidadeLista);
        pilha = new PilhaObj<>(capacidadePilha);
        fila = new FilaObj<>(capacidadeFila);
        contadorOperacoesEmpilhadas = 0;
    }

    public void salvar(TemaJogo obj) {
        lista.adicionaNoFim(obj);
    }

    // Método para deletar um objeto pelo id
    public void deletarPeloId(int id) {
        /*
        * ao encontrar o objeto com o ID correspondente, é feito um deslocamento dos elementos subsequentes para a esquerda,
        * sobrescrevendo o valor do índice atual com o valor do índice seguinte.
        * Em seguida, é adicionado um valor nulo no final da lista para substituir o último elemento.
        * Isso resulta na remoção efetiva do objeto com o ID fornecido.
        * */
        boolean encontrado = false;
        for (int i = 0; i < lista.getNroElem(); i++) {
            TemaJogo tema = lista.getElemento(i);
            if (tema.getId() == id) {
                for (int j = i; j < lista.getNroElem() - 1; j++) {
                    TemaJogo proximoTema = lista.getElemento(j + 1);
                    lista.adicionaNoIndice(proximoTema, j);
                }
                lista.adicionaNoFim(null); // Sobrescreve o último elemento
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("id inválido");
        }
    }

    // Método para aumentar o valor de um objeto pelo id
    public void aumentarValorPeloId(int id, Double valorDeAumento) {
        boolean encontrado = false;
        for (int i = 0; i < lista.getNroElem(); i++) {
            TemaJogo tema = lista.getElemento(i);
            if (tema.getId() == id) {
                tema.setValor(tema.getValor() + valorDeAumento);
                pilha.push(new Operacao(id, valorDeAumento));
                contadorOperacoesEmpilhadas++;
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("id inválido");
        }
    }

    // Método para diminuir o valor de um objeto pelo id
    public void diminuirValorPeloId(int id, Double valorDeDiminuicao) {
        boolean encontrado = false;
        for (int i = 0; i < lista.getNroElem(); i++) {
            TemaJogo tema = lista.getElemento(i);
            if (tema.getId() == id) {
                tema.setValor(tema.getValor() - valorDeDiminuicao);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("id inválido");
        }
    }

    // Método para desfazer as operações empilhadas
    public void desfazer(int qtdOperacoesADesfazer) {
        if (qtdOperacoesADesfazer < 0 || qtdOperacoesADesfazer > contadorOperacoesEmpilhadas) {
            System.out.println("Quantidade de operações inválida");
            return;
        }
        if (pilha.isEmpty()) {
            System.out.println("Nada a desfazer");
            return;
        }

        for (int i = 0; i < qtdOperacoesADesfazer; i++) {
            Operacao operacao = pilha.pop();
            diminuirValorPeloId(operacao.getId(), operacao.getValorDeAumento());
        }

        contadorOperacoesEmpilhadas -= qtdOperacoesADesfazer;
    }

    // Método para agendar a deleção de um objeto pelo id
    public void agendarDeletarPeloId(int id) {
        fila.insert(id);
    }

    // Método para executar as operações agendadas de deleção
    public void executarAgendado() {
        if (!fila.isEmpty()) {
            int id = fila.poll();
            deletarPeloId(id);
        }
    }

    public void salvarAposId(TemaJogo jogo, int id) {
        boolean encontrado = false;
        for (int i = 0; i < lista.getNroElem(); i++) {
            TemaJogo tema = lista.getElemento(i);
            if (tema.getId() == id) {
                lista.adicionaNoIndice(jogo, i + 1);
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            System.out.println("id inválido");
        }
    }

    public void exibe() {
        for (int i = 0; i < lista.getNroElem(); i++) {
            TemaJogo tema = lista.getElemento(i);
            System.out.println(tema);
        }
    }

    //EXIBE OS IDS PARES
    public void exibeRecursivo(int indice) {
        if (indice >= lista.getNroElem()) {
            return;
        }

        TemaJogo tema = lista.getElemento(indice);
        if (tema.getId() % 2 == 0) {
            System.out.println(tema);
        }

        exibeRecursivo(indice + 1);
    }

    public ListaObj<TemaJogo> getLista() {
        return lista;
    }

    public void setLista(ListaObj<TemaJogo> lista) {
        this.lista = lista;
    }
}
