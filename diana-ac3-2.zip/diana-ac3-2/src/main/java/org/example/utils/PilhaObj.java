package org.example.utils;

public class PilhaObj<T> {
    // Atributos
    private T[] pilha;
    private int topo;

    // Construtor
    public PilhaObj(int capacidade) {
        pilha = (T[]) new Object[capacidade];
        topo = -1;
    }

    // Método isEmpty
    public boolean isEmpty() {
        return topo == -1;
    }

    // Método isFull
    public boolean isFull() {
        return topo == pilha.length - 1;
    }

    // Método push
    public void push(T info) {
        if (isFull()) {
            System.out.println("Pilha cheia!");
            throw new IllegalStateException("Pilha cheia");
        } else {
            pilha[++topo] = info;
        }
    }

    // Método pop
    public T pop() {
        if (isEmpty()) {
            return null;
        }
        return pilha[topo--];
    }

    // Método peek
    public T peek() {
        if (isEmpty()) {
            return null;
        }
        return pilha[topo];
    }

    // Método exibe
    public void exibe() {
        if (isEmpty()) {
            System.out.println("Pilha vazia");
        } else {
            for (int i = topo; i >= 0; i--) {
                System.out.println(pilha[i]);
            }
        }
    }

    // Getter do topo
    public int getTopo() {
        return topo;
    }
}