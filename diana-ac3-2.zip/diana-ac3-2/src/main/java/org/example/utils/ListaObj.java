package org.example.utils;

public class ListaObj<T> {
    // Atributos
    private T[] lista;
    private int nroElem;

    // Construtor
    public ListaObj(int capacidade) {
        lista = (T[]) new Object[capacidade];
        nroElem = 0;
    }

    // Método isEmpty
    public boolean isEmpty() {
        return nroElem == 0;
    }

    // Método isFull
    public boolean isFull() {
        return nroElem == lista.length;
    }

    // Método adicionaNoFim
    public void adicionaNoFim(T valor) {
        if (isFull()) {
            throw new IllegalStateException("Lista cheia!");
        } else {
            lista[nroElem] = valor;
            nroElem++;
        }
    }

    // Método exibe
    public void exibe() {
        if (isEmpty()) {
            System.out.println("Lista vazia");
        } else {
            for (int i = 0; i < nroElem; i++) {
                System.out.println(lista[i]);
            }
        }
    }

    public T getElemento(int indice) {
        if (isEmpty()) {
            System.out.println("Lista vazia");
            return null;
        }

        if (indice < 0 || indice >= nroElem) {
            System.out.println("Índice inválido");
            return null;
        }

        return lista[indice];
    }


    // Método adicionaNoIndice
    public void adicionaNoIndice(T valor, int indice) {
        if (indice < 0 || indice > nroElem) {
            System.out.println("Índice inválido");
            return;
        }

        if (isFull()) {
            throw new IllegalStateException("Lista cheia!");
        }

        // Deslocar os valores para a direita
        for (int i = nroElem - 1; i >= indice; i--) {
            lista[i + 1] = lista[i];
        }

        // Inserir o novo valor no índice desejado
        lista[indice] = valor;
        nroElem++;
    }

    // Getters
    public int getNroElem() {
        return nroElem;
    }
}