package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RepositorioEmpresaJogo repositorio = new RepositorioEmpresaJogo(10, 10, 10);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            exibirMenu();
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    boolean jogoEhOnline = false;

                    System.out.print("Insire o ID do JOGO: ");
                    int ID = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Digite o nome do JOGO: ");
                    String nome = scanner.nextLine();

                    System.out.print("Digite o valor do JOGO: ");
                    double valor = scanner.nextDouble();

                    System.out.print("Digite o a nota do JOGO no MetaCritic: ");
                    double notaJogoMetaCritic = scanner.nextDouble();

                    System.out.print("Digite o a quantidade de unidades vendidas (ou players ativos) do JOGO: ");
                    int qtdVendidasOuPlayersAtivos = scanner.nextInt();
                    System.out.print("O Jogo é Online? (1- Sim/2-não) ");
                    int verificacaoJogoOnline = scanner.nextInt();
                    if(verificacaoJogoOnline == 1){
                        jogoEhOnline = true;
                    }


                    TemaJogo tema = new TemaJogo(ID, valor, qtdVendidasOuPlayersAtivos,
                            nome, notaJogoMetaCritic,jogoEhOnline);
                    repositorio.salvar(tema);
                    break;
                case 2:
                    System.out.print("Digite o ID do JOGO a ser deletado: ");
                    int idDeletar = scanner.nextInt();
                    repositorio.deletarPeloId(idDeletar);
                    break;
                case 3:
                    System.out.print("Digite o ID do JOGO para aumentar o valor: ");
                    int idAumentar = scanner.nextInt();
                    System.out.print("Digite o valor de aumento: ");
                    double valorAumento = scanner.nextDouble();
                    repositorio.aumentarValorPeloId(idAumentar, valorAumento);
                    break;
                case 4:
                    System.out.print("Digite o ID do JOGO para diminuir o valor: ");
                    int idDiminuir = scanner.nextInt();

                    System.out.print("Digite o valor de diminuição: ");
                    double valorDiminuicao = scanner.nextDouble();

                    repositorio.diminuirValorPeloId(idDiminuir, valorDiminuicao);
                    break;
                case 5:
                    System.out.print("Digite a quantidade de operações a serem desfeitas: ");

                    int qtdOperacoes = scanner.nextInt();

                    repositorio.desfazer(qtdOperacoes);
                    break;
                case 6:
                    System.out.print("Digite o ID do JOGO a ser agendado para deleção: ");

                    int idAgendar = scanner.nextInt();

                    repositorio.agendarDeletarPeloId(idAgendar);
                    break;
                case 7:
                    repositorio.executarAgendado();
                    break;
                case 8:
                    System.out.print("Digite o ID do JOGO: ");
                    int idSalvarApos = scanner.nextInt();

                    System.out.print("Digite o nome do JOGO: ");
                    String nomeSalvarApos = scanner.nextLine();

                    System.out.print("Digite o valor do JOGO: ");
                    double valorSalvarApos = scanner.nextDouble();

                    TemaJogo temaSalvarApos = new TemaJogo(idSalvarApos, valorSalvarApos, 10022,
                            nomeSalvarApos, 10.0,true);
                    break;
                case 9:
                    repositorio.exibe();
                    break;
                case 10:
                    repositorio.exibeRecursivo(0);
                    break;
                case 11:
                    exibirRelatorio(repositorio);
                    break;
                case 12:
                    System.out.println("Finalizando o programa.");
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }
    private static void exibirMenu() {
        System.out.println("Menu de Opções");
        System.out.println("1. Salvar objeto");
        System.out.println("2. Deletar objeto pelo ID");
        System.out.println("3. Aumentar valor pelo ID");
        System.out.println("4. Diminuir valor pelo ID");
        System.out.println("5. Desfazer operações");
        System.out.println("6. Agendar deleção pelo ID");
        System.out.println("7. Executar agendamento");
        System.out.println("8. Salvar após ID");
        System.out.println("9. Exibir objetos salvos");
        System.out.println("10. Exibir objetos de IDs pares");
        System.out.println("11. Exibir relatório");
        System.out.println("12. Finalizar");
    }
    public static void exibirRelatorio(RepositorioEmpresaJogo repositorio) {
        System.out.printf("%-20s%-20s%-20s%-20s%-20s%-20s%n", "ID", "id", "valor", "players", "nota", "horas de jogo");

        double[][] matrizNumerica = new double[repositorio.getLista().getNroElem()][6];
        for (int i = 0; i < repositorio.getLista().getNroElem(); i++) {
            TemaJogo jogo = repositorio.getLista().getElemento(i);
            matrizNumerica[i][0] = jogo.getId();
            matrizNumerica[i][1] = jogo.getValor();
            matrizNumerica[i][2] = jogo.getQtdVendidasOuPlayersAtivos();
            matrizNumerica[i][3] = jogo.getNotaJogoMetacritic();
            matrizNumerica[i][4] = 20.0;
        }

        System.out.print("                    \n");
        for (int i = 0; i < repositorio.getLista().getNroElem(); i++) {
            for (int j = 0; j < 5; j++) {
                if(j==0){
                    System.out.printf("%-20d", (int) matrizNumerica[i][j]);
                }
                    System.out.printf("%-20.2f", matrizNumerica[i][j]);

            }
            System.out.println();
        }

        double[] vetorMediasColunas = new double[5];
        for (int j = 1; j < 5; j++) {
            double soma = 0;
            for (int i = 0; i < repositorio.getLista().getNroElem(); i++) {
                soma += matrizNumerica[i][j];
            }
            vetorMediasColunas[j] = soma / repositorio.getLista().getNroElem();
        }

        System.out.print("                    \n");
        for (int j = 1; j < 5; j++) {
            if(j==1){
                System.out.printf("%n%-20s%n", "Média");
            }
            System.out.printf("%-20.2f", vetorMediasColunas[j]);
        }


    }

}